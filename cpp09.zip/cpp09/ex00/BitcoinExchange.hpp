#ifndef BITCOINEXCHANGE_HPP
#define BITCOINEXCHANGE_HPP

#include <iostream>
#include <sstream>
#include <fstream>
#include <map>

void	BitcoinExchange(std::string _av, std::map<std::string, float> &map);
void	data_(std::map<std::string, float> &map);

#endif
